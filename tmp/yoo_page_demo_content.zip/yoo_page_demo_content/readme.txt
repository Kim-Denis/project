How to setup the template with demo content

1. make a clean installation of Joomla! 1.5.0
2. install template
3. install YOOaccordion module
4. install YOOcarousel module
5. install YOOdrawer module
6. install YOOslider module
7. install YOOtoppanel module
8. install YOOlogin module
9. install YOOscroller module
10. install YOOtooltip plugin
11. copy "image"-folder into your joomla installation
12. import database dump (demo_content.sql) into your database

done!

super administrator login
username: admin
password: demo

Note: Some demo images are replaced and show up like a black square. Some other have Watermarks.
This is because the demo content is only for demonstration use.
Re-use of any graphics, icons or photos from the demo content for any purpose is strictly prohibited.