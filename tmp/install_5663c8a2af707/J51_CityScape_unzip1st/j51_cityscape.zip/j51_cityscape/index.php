<?php

defined( '_JEXEC' ) or die( 'Restricted access' );

JPlugin::loadLanguage( 'tpl_SG1' );

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" >

<head>

<jdoc:include type="head" />



<link rel="stylesheet" href="templates/system/css/system.css" type="text/css" />
<link rel="stylesheet" href="templates/<?php echo $this->template ?>/css/template.css" type="text/css" />

<?php if ($this->countModules('hornav')): ?>
<script language="javascript" type="text/javascript" src="<?php echo $this->baseurl ?>/templates/<?php echo $this->template?>/js/moomenu.js"></script>
<?php endif; ?>

</head>





<!--[if IE 7]>
<link href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template;?>/css/ie7.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
window.addEvent('domready', function(){
   var menu_li_els = document.getElementById('hornav').firstChild.childNodes;
   for(var i=0;i<menu_li_els.length; i++) {
      menu_li_els[i].insertBefore(document.createElement('div'), menu_li_els[i].lastChild);
   }
});
</script>
<![endif]-->

<!--[if IE 6]>
<script type="text/javascript">
window.addEvent('domready', function(){
   var menu_li_els = document.getElementById('hornav').firstChild.childNodes;
   for(var i=0;i<menu_li_els.length; i++) {
      menu_li_els[i].insertBefore(document.createElement('div'), menu_li_els[i].lastChild);
   }
});
</script>
<link href="<?php echo $this->baseurl;?>/templates/<?php echo $this->template;?>/css/ie6.css" rel="stylesheet" type="text/css" />
<![endif]-->

<?php
if($this->countModules('left and right') == 0) $contentwidth = "100";
if($this->countModules('left or right') == 1) $contentwidth = "80";
if($this->countModules('left and right') == 1) $contentwidth = "60";
?> 

<body>

<div id="wrapper">

   <div id="header">
    <div class="inside">

	  
	
      <jdoc:include type="modules" name="header" style="xhtml" />

	    </div>
  </div>

    <div id="top">
	<div id="topnav_l">
    <div id="topnav">
	<div id="topnav_r">
      <div id="hornav">
      <jdoc:include type="modules" name="hornav" />
      </div>
    </div>
  </div>
</div></div>


  
<div id="content_wrapper">  


  
  <div id="content<?php echo $contentwidth; ?>">
    <div class="inside">
	
	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
  
  <?php if ($this->countModules( 'user1' )) : ?>
    <td valign="top">    
	<div class="moduletable3">
      <jdoc:include type="modules" name="user1" style="rounded" />
    </div></td>
	<?php endif; ?>
	<?php if ($this->countModules( 'user2' )) : ?>
    <td valign="top">	    
	<div class="moduletable3">
      <jdoc:include type="modules" name="user2" style="rounded" />
    </div>
	</td>
	<?php endif; ?>
	
  </tr>
</table>
	
	<div class="maincontent">
      <jdoc:include type="component" /> 
	  </div>  
	  
	  	<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
  <td>
  <?php if ($this->countModules( 'user3' )) : ?>
    <td valign="top">    
	<div class="moduletable3">
      <jdoc:include type="modules" name="user3" style="rounded" />
    </div></td>
	<?php endif; ?>
	<?php if ($this->countModules( 'user4' )) : ?>
    <td valign="top">	    
	<div class="moduletable3">
      <jdoc:include type="modules" name="user4" style="rounded" />
    </div>
	</td>
	<?php endif; ?>
	</td>
  </tr>
</table>


</div>
</div>

  <div id="rightcol">
  <div class="leftpadding">
    <div class="moduletable">
      <jdoc:include type="modules" name="right" style="table" />
    </div>
	</div>
	
	<?php if ($this->countModules( 'user5' )) : ?>
	<div class="menubase"><jdoc:include type="modules" name="user5" style="table" /></div>
	<?php endif; ?>
	
  </div>

</div>
  

  
 <br class="ff_fix"></br>

 <div id="base_bg">&nbsp;</div>
</div>

    <div id="banner">
    <div class="inside">
      <jdoc:include type="modules" name="banner" style="none" />
    </div>
  </div>

  <div id="footer">
    <div class="inside">
      <jdoc:include type="modules" name="footer" style="none" />
		  
    <p><strong>Template by <a href="http://www.joomla51.com">Joomla51.com</a></strong> 
    </p>
	  
    </div>
  </div>

<!--end of wrap-->


</body> 
</html>

